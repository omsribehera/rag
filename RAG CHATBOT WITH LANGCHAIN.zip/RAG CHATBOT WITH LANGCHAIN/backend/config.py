import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    GOOGLE_CREDENTIALS = os.getenv("GOOGLE_APPLICATION_CREDENTIALS", "credentials.json")
    GOOGLE_DOC_ID = os.getenv("GOOGLE_DOC_ID")
    GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
    FAISS_DIR = os.getenv("FAISS_DIR", "data/faiss_index")
    EMBEDDING_MODEL = "models/embedding-001"
    LLM_MODEL = "gemini-1.5-pro"
