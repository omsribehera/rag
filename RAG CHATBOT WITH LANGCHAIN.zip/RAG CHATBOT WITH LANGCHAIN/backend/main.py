from fastapi import FastAPI
from backend.gdocs_service import fetch_google_doc
from backend.rag_engine import RAGEngine
from backend.schemas import QueryRequest, QueryResponse
from backend.config import Config

app = FastAPI(title="RAG Chatbot with Google Docs")

# Initialize RAG Engine
doc_text = fetch_google_doc(Config.GOOGLE_DOC_ID)
rag_engine = RAGEngine(doc_text)

@app.post("/ask", response_model=QueryResponse)
async def ask_doc(query: QueryRequest):
    answer = rag_engine.ask(query.question)
    return QueryResponse(answer=answer)
