import streamlit as st
import requests

API_URL = "http://127.0.0.1:8000/ask"

st.set_page_config(page_title="RAG Chatbot (Google Docs)", layout="centered")

st.title("📄 RAG Chatbot with Google Docs")
st.write("Ask questions based on the integrated Google Doc!")

if "history" not in st.session_state:
    st.session_state["history"] = []

user_input = st.text_input("💬 Your Question:")

if st.button("Ask") and user_input:
    with st.spinner("Thinking..."):
        response = requests.post(API_URL, json={"question": user_input})
        answer = response.json().get("answer", "Error")
        st.session_state["history"].append((user_input, answer))

for q, a in reversed(st.session_state["history"]):
    st.markdown(f"**You:** {q}")
    st.markdown(f"**Bot:** {a}")
    st.write("---")
