import os
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import FAISS
from langchain.embeddings import GoogleGenerativeAIEmbeddings
from langchain_google_genai import ChatGoogleGenerativeAI
from backend.config import Config

class RAGEngine:
    def __init__(self, doc_text: str):
        self.doc_text = doc_text
        self.embeddings = GoogleGenerativeAIEmbeddings(model=Config.EMBEDDING_MODEL)
        self.llm = ChatGoogleGenerativeAI(model=Config.LLM_MODEL)
        self.vectorstore = self._initialize_vectorstore()

    def _initialize_vectorstore(self):
        """Load or create FAISS vector DB"""
        if os.path.exists(Config.FAISS_DIR):
            return FAISS.load_local(Config.FAISS_DIR, self.embeddings, allow_dangerous_deserialization=True)

        splitter = RecursiveCharacterTextSplitter(chunk_size=600, chunk_overlap=50)
        chunks = splitter.split_text(self.doc_text)
        vectorstore = FAISS.from_texts(chunks, self.embeddings)
        vectorstore.save_local(Config.FAISS_DIR)
        return vectorstore

    def ask(self, question: str) -> str:
        retriever = self.vectorstore.as_retriever(search_type="similarity", search_kwargs={"k": 3})
        docs = retriever.get_relevant_documents(question)

        context = "\n".join([d.page_content for d in docs])
        prompt = f"Context:\n{context}\n\nQuestion: {question}\n\nAnswer comprehensively:"

        response = self.llm.invoke(prompt)
        return response.content
