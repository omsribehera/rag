from googleapiclient.discovery import build
from google.oauth2 import service_account
from backend.config import Config

def fetch_google_doc(doc_id: str) -> str:
    """Fetch content from Google Docs"""
    creds = service_account.Credentials.from_service_account_file(
        Config.GOOGLE_CREDENTIALS,
        scopes=["https://www.googleapis.com/auth/documents.readonly"]
    )
    service = build("docs", "v1", credentials=creds)
    doc = service.documents().get(documentId=doc_id).execute()

    text_content = []
    for element in doc.get("body", {}).get("content", []):
        if "paragraph" in element:
            for text_run in element["paragraph"].get("elements", []):
                if "textRun" in text_run:
                    text_content.append(text_run["textRun"]["content"])
    return "".join(text_content).strip()
